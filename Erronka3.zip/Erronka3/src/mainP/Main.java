package mainP;

import loginRegister.Login;

/**
 * {@code Main} klaseak aplikazioaren exekuzioa hasieratzen du.
 * Hemen, saioa hasi eta login pantaila bistaratu egiten da.
 */
public class Main {
    /**
     * Main metoda, aplikazioaren exekuzioa hasieratzen duena.
     * 
     * @param args komando lerroko argumentuak (erabiltzen ez direnak).
     */
    public static void main(String[] args) {
        Login login = new Login();
        login.setLocationRelativeTo(null);
        login.setVisible(true);
    }
}
