package bezeroPant;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import datuBase.DB;
import saltzailePant.BezeroAldaketaPant;

/**
 * BezeroDatuakAldatu klaseak bezeroen datuak aldatzeko interfazea erakusten duen klasea da.
 * Bezeroen izen, abizen, helbide, email eta telefonoa aldatu daitezke.
 */
public class BezeroDatuakAldatu extends JFrame {

    private static final long serialVersionUID = 1L;
    DB datuBase;
    static int idBezero;
    static int minSal;
    static int maxSal;
    static String kategori;

    JPanel dPanel;
    JPanel dPaneles;

    JLabel izena;
    JLabel abizena;
    JLabel helbidea;
    JLabel emaila;
    JLabel telefonoa;

    JTextField tIzena;
    JTextField tAbizena;
    JTextField tHelbidea;
    JTextField tEmaila;
    JTextField tTelefonoa;

    /**
     * BezeroDatuakAldatu klasearen eraikitzailea.
     * Bezeroen datuak aldatzeko interfazea konfiguratzen du.
     * @param id Bezeroaren identifikazio zenbakia
     * @param min Minimoa saldutako kopurua
     * @param max Maximoa saldutako kopurua
     * @param kategoria Bezeroen kategoria 
     */
    public BezeroDatuakAldatu(int id, int min, int max, String kategoria) {
        idBezero = id;
        minSal = min;
        maxSal = max;
        kategori = kategoria;
        datuBase = new DB();
        dPanel = new JPanel(new GridLayout(5, 2));
        dPaneles = new JPanel();

        izena = new JLabel("IZENA:");
        abizena = new JLabel("ABIZENA:");
        helbidea = new JLabel("HELBIDEA:");
        emaila = new JLabel("EMAILA:");
        telefonoa = new JLabel("TELEFONOA:");

        tIzena = new JTextField(datuBase.getInfoBezeroTable("IZENA", idBezero), 20);
        tAbizena = new JTextField(datuBase.getInfoBezeroTable("ABIZENA", idBezero), 20);
        tHelbidea = new JTextField(datuBase.getInfoBezeroTable("HELBIDEA", idBezero), 20);
        tEmaila = new JTextField(datuBase.getInfoBezeroTable("EMAILA", idBezero), 20);
        tTelefonoa = new JTextField(datuBase.getInfoBezeroTeleTable(idBezero), 20);

        JButton bAldatu = new JButton("ALDATU");
        JButton bAtzera = new JButton("ATZERA");

        dPanel.add(izena);
        dPanel.add(tIzena);
        dPanel.add(abizena);
        dPanel.add(tAbizena);
        dPanel.add(helbidea);
        dPanel.add(tHelbidea);
        dPanel.add(emaila);
        dPanel.add(tEmaila);
        dPanel.add(telefonoa);
        dPanel.add(tTelefonoa);
        dPaneles.add(dPanel);
        dPaneles.add(bAldatu);
        dPaneles.add(bAtzera);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().add(dPaneles);
        this.setSize(550, 200);

        // Ekintza entzuleak
        bAldatu.addActionListener(e -> datuakAldatu());
        bAtzera.addActionListener(e -> atzera());
    }

    /**
     * Bezeroaren datuak datu-basean aldatzeko metodoa.
     * Erabiltzaileak sartutako datuak datu-basean eguneratzen ditu.
     * @see DB#eguneratuBezeroaTable(int, String, String, String, String)
     * @see DB#eguneratuBezeroaTeleTable(int, String)
     */
    public void datuakAldatu() {
        this.dispose();
        int opcion = JOptionPane.showConfirmDialog(null, "Datuak aldatu nahi dituzu?", "", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            datuBase.eguneratuBezeroaTable(idBezero, tIzena.getText(), tAbizena.getText(), tHelbidea.getText(), tEmaila.getText());
            datuBase.eguneratuBezeroaTeleTable(idBezero, tTelefonoa.getText());
            if (kategori.equals("saltzaile")) {
                BezeroAldaketaPant a = new BezeroAldaketaPant();
                a.setLocationRelativeTo(null);
                a.setVisible(true);
            } else {
                BezeroPant a = new BezeroPant(idBezero, minSal, maxSal, kategori);
                a.setLocationRelativeTo(null);
                a.setVisible(true);
            }
        } else {
            this.setVisible(true);
        }
    }

    /**
     * Atzerako botoak sakatzean interfazea itzultzen duen metodoa.
     */
    public void atzera() {
        this.dispose();
        if (kategori.equals("saltzaile")) {
            BezeroAldaketaPant a = new BezeroAldaketaPant();
            a.setLocationRelativeTo(null);
            a.setVisible(true);
        } else {
            BezeroPant a = new BezeroPant(idBezero, minSal, maxSal, kategori);
            a.setLocationRelativeTo(null);
            a.setVisible(true);
        }
    }
}