package bezeroPant;

import java.awt.Dimension;

import javax.swing.*;
import saltzailePant.ProduktuAldaketaPant;

/**
 * Bilaketen produktuen filtroa ezartzeko JFrame.
 */
public class Filtro extends JFrame {

    private static final long serialVersionUID = 1L;
    private JSlider salneurriMaxS;
    private JSlider salneurriMinS;
    private JComboBox<String> kategoriaComboBox;
    private JButton bBilatu;
    private JButton bFiltroGabe;
    static int idBezero;
    static int minSal;
    static int maxSal;
    static String kategori;

    /**
     * Filtro klasearen eraikitzailea.
     * @param id Erabiltzailearen identifikadorea.
     * @param min filtroaren txertaketa.
     * @param max filtroaren gehiketa.
     * @param kategoria filtroaren kategoria.
     */
    public Filtro(int id, int min, int max, String kategoria) {
        idBezero = id;
        minSal = min;
        maxSal = max;
        kategori = kategoria;
        setTitle("BILAKETA FILTRATU");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(650, 200);

        JPanel panel = new JPanel();

        JLabel salneurriMinLabel = new JLabel("Salneurri MIN:");
        salneurriMinS = new JSlider(JSlider.HORIZONTAL, 0, 10000, 0);
        salneurriMinS.setMajorTickSpacing(1000);
        salneurriMinS.setMinorTickSpacing(5000);
        salneurriMinS.setPaintTicks(true);
        salneurriMinS.setPaintLabels(true);
        salneurriMinS.setPreferredSize(new Dimension(500, 50));
        panel.add(salneurriMinLabel);
        panel.add(salneurriMinS);

        JLabel salneurriMaxLabel = new JLabel("Salneurri MAX:");
        salneurriMaxS = new JSlider(JSlider.HORIZONTAL, 0, 10000, 10000);
        salneurriMaxS.setMajorTickSpacing(1000);
        salneurriMaxS.setMinorTickSpacing(500);
        salneurriMaxS.setPaintTicks(true);
        salneurriMaxS.setPaintLabels(true);
        salneurriMaxS.setPreferredSize(new Dimension(500, 50));
        panel.add(salneurriMaxLabel);
        panel.add(salneurriMaxS);

        JLabel kategoriL = new JLabel("Kategoria:");
        String[] kategoris = {"CPU", "Video Card", "Mother Board", "Storage"};
        kategoriaComboBox = new JComboBox<>(kategoris);
        panel.add(kategoriL);
        panel.add(kategoriaComboBox);

        bBilatu = new JButton("BILATU");
        bFiltroGabe = new JButton("FILTRO GABE");
        bBilatu.addActionListener(e -> bilatu());
        bFiltroGabe.addActionListener(e -> filtroGabe());
        panel.add(bBilatu);
        panel.add(bFiltroGabe);
        add(panel);
    }
    
    /**
     * Filtroa ezabatzeko ekintza kudeatzen duen metodoa.
     */
    public void filtroGabe() {
        dispose();
        if (idBezero == 0) {
            ProduktuAldaketaPant a = new ProduktuAldaketaPant(idBezero, 0, 10000, "*");
            a.setLocationRelativeTo(null);
            a.setVisible(true);
        } else {
            BezeroPant a = new BezeroPant(idBezero, 0, 10000, "*");
            a.setLocationRelativeTo(null);
            a.setVisible(true);
        }
    }
    
    /**
     * Filtroa aplikatzeko ekintza kudeatzen duen metodoa.
     */
    public void bilatu() {
        int salnerriMinBalorea = salneurriMinS.getValue();
        int salnerriMaxBalorea = salneurriMaxS.getValue();
        String kategoria = (String) kategoriaComboBox.getSelectedItem();
        if (salnerriMinBalorea > salnerriMaxBalorea) {
            int opcion = JOptionPane.showConfirmDialog(null, "Salneurri maximoa minimoaren txikiagoa da, filtraketa errepikatu nahi duzu?", "", JOptionPane.YES_NO_OPTION);
            if (opcion == JOptionPane.YES_OPTION) {
                setVisible(true);
            } else {
                dispose();
                if (idBezero == 0) {
                    ProduktuAldaketaPant a = new ProduktuAldaketaPant(idBezero, minSal, maxSal, kategori);
                    a.setLocationRelativeTo(null);
                    a.setVisible(true);
                } else {
                    BezeroPant a = new BezeroPant(idBezero, minSal, maxSal, kategori);
                    a.setLocationRelativeTo(null);
                    a.setVisible(true);
                }
            }
        } else {
            minSal = salnerriMinBalorea;
            maxSal = salnerriMaxBalorea;
            kategori = kategoria;
            dispose();
            if (idBezero == 0) {
                ProduktuAldaketaPant a = new ProduktuAldaketaPant(idBezero, minSal, maxSal, kategori);
                a.setLocationRelativeTo(null);
                a.setVisible(true);
            } else {
                BezeroPant a = new BezeroPant(idBezero, minSal, maxSal, kategori);
                a.setLocationRelativeTo(null);
                a.setVisible(true);
            }
        }
    }
}
