package bezeroPant;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import datuBase.DB;
import datuBase.Produktuak;
import loginRegister.Login;

/**
 * BezeroPant klaseak bezeroen interfazea erakusten duen JFrame-a da.
 * Produktuak erosteko, bezeroaren datuak aldatzeko, saioa itxi eta kondua ezabatu erabiltzen da.
 */
public class BezeroPant extends JFrame {

    private static final long serialVersionUID = 1L;
    private static DB datuBase;
    private static int idBezero;
    private static int minSal;
    private static int maxSal;
    private static String kategori;
    private static int idSele;
    JComboBox<String> comboBox;
    Produktuak produktuak;

    JLabel vacio1;
    JLabel vacio2;
    JLabel izena1;
    JLabel deskribapena1;
    JLabel kategoria1;
    JLabel stock1;
    JLabel kopurua1;
    JLabel salneurria1;

    JLabel izena2;
    JLabel deskribapena2;
    JLabel kategoria2;
    JLabel stock2;
    JLabel kopurua2;
    JLabel salneurria2;

    /**
     * BezeroPant klasearen eraikitzailea.
     * @param id Bezeroaren identifikazio zenbakia
     * @param min Minimoa saldutako kopurua
     * @param max Maximoa saldutako kopurua
     * @param kategoria Bezeroen kategoria
     */
    public BezeroPant(int id, int min, int max, String kategoria) {
        idBezero = id;
        minSal = min;
        maxSal = max;
        kategori = kategoria;
        datuBase = new DB();
        if (kategori.equals("*")) {
            produktuak = datuBase.produktuak();
        } else {
            produktuak = datuBase.produktuakFiltratu(min, max, kategoria);
        }
        idSele = produktuak.getProduktuId(0);

        vacio1 = new JLabel("                                                                ");
        vacio2 = new JLabel("                                                                ");
        izena1 = new JLabel("IZENA");
        deskribapena1 = new JLabel("DESKRIBAPENA:");
        kategoria1 = new JLabel("KATEGORIA:");
        stock1 = new JLabel("STOCK:");
        kopurua1 = new JLabel("KOPURUA:");
        salneurria1 = new JLabel("SALNEURRIA:");

        izena2 = new JLabel(datuBase.getInfoProduktuTable("IZENA", idSele));
        deskribapena2 = new JLabel(datuBase.getInfoProduktuTable("DESKRIBAPENA", idSele));
        kategoria2 = new JLabel(datuBase.getInfoKategoria(idSele));
        stock2 = new JLabel(datuBase.getInfoStock(idSele));
        kopurua2 = new JLabel("1");
        salneurria2 = new JLabel(datuBase.getInfoProduktuTable("SALNEURRIA", idSele) + "€");

        JButton bFiltrar = new JButton("FILTRAR");
        JButton bSum = new JButton("+");
        JButton bRes = new JButton("-");
        JButton bErosi = new JButton("EROSI");

        comboBox = new JComboBox<>();
        for (int i = 0; i < produktuak.getProduktuList().length; i++) {
            comboBox.addItem(produktuak.getProduktuList()[i].toString());
        }

        JPanel panel = new JPanel();
        panel.add(vacio1);
        panel.add(bFiltrar);
        panel.add(comboBox);
        panel.add(vacio2);

        JPanel pDatuak1 = new JPanel(new GridLayout(6, 1));
        JPanel pDatuak2 = new JPanel(new GridLayout(6, 1));
        pDatuak1.setPreferredSize(new Dimension(200, 110));
        pDatuak2.setPreferredSize(new Dimension(400, 110));
        pDatuak1.add(izena1);
        pDatuak2.add(izena2);
        pDatuak1.add(deskribapena1);
        pDatuak2.add(deskribapena2);
        pDatuak1.add(kategoria1);
        pDatuak2.add(kategoria2);
        pDatuak1.add(stock1);
        pDatuak2.add(stock2);
        pDatuak1.add(kopurua1);
        pDatuak2.add(kopurua2);
        pDatuak1.add(salneurria1);
        pDatuak2.add(salneurria2);

        JPanel pBotoi = new JPanel();
        pBotoi.add(bSum);
        pBotoi.add(bRes);
        pBotoi.add(bErosi);

        JMenu menu = new JMenu(datuBase.getInfoBezeroTable("IZENA", idBezero) + " " + datuBase.getInfoBezeroTable("ABIZENA", idBezero));
        JMenuBar jmb = new JMenuBar();
        jmb.add(menu);
        JMenuBar menuBar = new JMenuBar();
        JMenuItem bDatuakAldatu = new JMenuItem("DATUAK ALDATU");
        JMenuItem bSaioaItxi = new JMenuItem("SAIOA ITXI");
        JMenuItem bBezeroEzabatu = new JMenuItem("KONTUA EZABATU");
        menu.add(bDatuakAldatu);
        menu.add(bSaioaItxi);
        menu.add(bBezeroEzabatu);

        JPanel pPaneles = new JPanel();
        pPaneles.add(menuBar);
        pPaneles.add(panel);
        pPaneles.add(pDatuak1);
        pPaneles.add(pDatuak2);
        pPaneles.add(pBotoi);

        setTitle("BEZERO");
        setJMenuBar(jmb);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().add(pPaneles);
        setSize(700, 270);

        comboBox.addActionListener(e -> {
            idSele = datuBase.getIdFromIzenProduktu((String) comboBox.getSelectedItem());
            izena2.setText(datuBase.getInfoProduktuTable("IZENA", idSele));
            deskribapena2.setText(datuBase.getInfoProduktuTable("DESKRIBAPENA", idSele));
            kategoria2.setText(datuBase.getInfoKategoria(idSele));
            stock2.setText(datuBase.getInfoStock(idSele));
            kopurua2.setText("1");
            salneurria2.setText(datuBase.getInfoProduktuTable("SALNEURRIA", idSele) + "€");
        });

        bDatuakAldatuJOption(this, bDatuakAldatu);
        bSaioaItxiJOption(this, bSaioaItxi);
        bBezeroEzabatuJOption(this, bBezeroEzabatu);

        bFiltrar.addActionListener(e -> filtar());
        bSum.addActionListener(e -> sumar());
        bRes.addActionListener(e -> restar());
        bErosi.addActionListener(e -> erosi());
    }
    
    /**
     * Produktua erosi egitean erabiliko den metodoa.
     * Erosi botoia sakatzean, erabiltzaileari konfirmazio mezua erakusten dio.
     * Erosi nahi duenak "Bai" botoia sakatzen badu, datu-basean produktu kopurua eguneratzen, eskari berria sortzen du eta pantaila berria irekitzen du.
     */
    public void erosi() {
    	int opcion = JOptionPane.showConfirmDialog(null, "Eroskta egin nahi duzu?", "", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
        	datuBase.produktuErosi(idSele, Integer.parseInt(kopurua2.getText()), idBezero);
        	this.dispose();
        	BezeroPant a = new BezeroPant(idBezero, minSal, maxSal, kategori);
            a.setLocationRelativeTo(null);
            a.setVisible(true);
        }
    	
    }
    
    /**
     * Produktu kopurua gehitzeko metodoa.
     * "+" botoia sakatzean, produktu kopurua gehitzen du, stock-eko produktu kopurua baino txikiagoa baldin bada.
     */
    public void sumar() {
        int auxStock = Integer.parseInt(stock2.getText());
        int aux = Integer.parseInt(kopurua2.getText()) + 1;
        if (aux <= auxStock) {
            String aux2 = "" + aux;
            kopurua2.setText(aux2);
            double auxSalneurri = Double.parseDouble(datuBase.getInfoProduktuTable("SALNEURRIA", idSele)) * aux;
            DecimalFormat formato = new DecimalFormat("#.##");
            String salneurriFinal = formato.format(auxSalneurri);
            String salneurri = "" + salneurriFinal;
            salneurria2.setText(salneurri + "€");
        }
    }

    /**
     * Produktu kopurua kendeko metodoa.
     * "-" botoia sakatzean, produktu kopurua kentzen du, 0 baino handiagoa baldin bada.
     */
    public void restar() {
        int aux = Integer.parseInt(kopurua2.getText()) - 1;
        if (aux > 0) {
            String aux2 = "" + aux;
            kopurua2.setText(aux2);
            double auxSalneurri = Double.parseDouble(datuBase.getInfoProduktuTable("SALNEURRIA", idSele)) * aux;
            DecimalFormat formato = new DecimalFormat("#.##");
            String salneurriFinal = formato.format(auxSalneurri);
            String salneurri = "" + salneurriFinal;
            salneurria2.setText(salneurri + "€");
        }
    }

    /**
     * Produktuak filtratzeko metodoa.
     * "FILTRAR" botoia sakatzean, Filtro klasearen instantzia bat sortzen du eta pantaila berria irekitzen du.
     */
    public void filtar() {
        dispose();
        Filtro a = new Filtro(idBezero, minSal, maxSal, kategori);
        a.setLocationRelativeTo(null);
        a.setVisible(true);
    }

    /**
     * "DATUAK ALDATU" menu aukeran egiten den akzioa.
     * BezeroDatuakAldatu klasearen instantzia bat sortzen du eta pantaila berria irekitzen du.
     */
    public static void bDatuakAldatuJOption(BezeroPant frame, JMenuItem bDatuakAldatu) {
        bDatuakAldatu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                BezeroDatuakAldatu a = new BezeroDatuakAldatu(idBezero, minSal, maxSal, kategori);
                a.setLocationRelativeTo(null);
                a.setVisible(true);
            }
        });
    }

    /**
     * "SAIOA ITXI" menu aukeran egiten den akzioa.
     * Saioa itxi nahi duen erabiltzaileari konfirmazio mezua erakusten dio.
     * "Bai" botoia sakatzen badu, saioa itxi eta login pantaila berria irekitzen du.
     */
    public static void bSaioaItxiJOption(BezeroPant frame, JMenuItem bSaioaItxi) {
        bSaioaItxi.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                int opcion = JOptionPane.showConfirmDialog(null, "Saioa itxi nahi duzu?", "", JOptionPane.YES_NO_OPTION);
                if (opcion == JOptionPane.YES_OPTION) {
                    Login login = new Login();
                    login.setLocationRelativeTo(null);
                    login.setVisible(true);
                } else {
                    frame.setVisible(true);
                }
            }
        });
    }

    /**
     * "KONTUA EZABATU" menu aukeran egiten den akzioa.
     * Bezeroa ezabatu nahi duen erabiltzaileari konfirmazio mezua erakusten dio.
     * "Bai" botoia sakatzen badu, bezeroaren kontua ezabatzen da eta login pantaila berria irekitzen du.
     */
    public static void bBezeroEzabatuJOption(BezeroPant frame, JMenuItem bBezeroEzabatu) {
        bBezeroEzabatu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                int opcion = JOptionPane.showConfirmDialog(null, "Kontua ezabatu nahi duzu?", "", JOptionPane.YES_NO_OPTION);
                if (opcion == JOptionPane.YES_OPTION) {
                    datuBase.bezeroEzabatuTeleTable(idBezero);
                    datuBase.bezeroEzabatuTable(idBezero);
                    Login login = new Login();
                    login.setLocationRelativeTo(null);
                    login.setVisible(true);
                } else {
                    frame.setVisible(true);
                }
            }
        });
    }
}