package datuBase;

import java.util.Arrays;

/**
 * {@code Produktuak} klaseak produktuen zerrenda bat gordetzen du, hau da,
 * {@code Produktua} objektuen bilduma.
 */
public class Produktuak {
    private Produktua[] produktuak;
    
    /**
     * {@code Produktuak} klaseko konstruktorea. Hasieran, produktuen zerrenda
     * hutsa sortzen da.
     */
    public Produktuak(){
        produktuak = new Produktua[0];
    }
    
    /**
     * {@code Produktua} objektua {@code produktuak} zerrendan gehitzen du.
     * 
     * @param produktua gehitu nahi den {@code Produktua} objektua
     */
    public void addProduktuak(Produktua produktua){
        this.produktuak = Arrays.copyOf(this.produktuak, this.produktuak.length + 1);
        this.produktuak[this.produktuak.length - 1] = produktua;
    }
    
    /**
     * {@code produktuak} zerrendako elementu guztiak bueltatzen ditu.
     * 
     * @return produktuen zerrenda
     */
    public Produktua[] getProduktuList() {
        return produktuak;
    }
    
    /**
     * {@code produktuak} zerrendako {@code index} posizioko elementua bueltatzen du.
     * 
     * @param index lortu nahi den elementuaren posizioa
     * @return produktua {@code index} posizioan
     */
    public Produktua getProduktu(int index) {
        return this.produktuak[index];
    }
    
    /**
     * {@code produktuak} zerrendako {@code index} posizioko elementuaren ID-a bueltatzen du.
     * 
     * @param index lortu nahi den elementuaren posizioa
     * @return produktuaren ID-a
     */
    public int getProduktuId(int index) {
        return this.produktuak[index].getId();
    }
    
    /**
     * Produktuen zerrenda pantailaratzeko metodoa.
     */
    public void getProduktuak(){
        for (int i=0; i<this.produktuak.length; i++){
            System.out.println(produktuak[i].toString());
        }
    }
    
    /**
     * Produktuen zerrendaren informazioa string formatuan itzultzen du.
     * 
     * @return produktuen zerrendaren informazioa
     */
    @Override
    public String toString() {
        String all = "";
        for (int i=0; i<this.produktuak.length; i++){
            all += produktuak[i].toString() + "\n";
        }
        return all;
    }
}
