package datuBase;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.swing.JOptionPane;


/**
 * {@code DB} klasea datu basearekin konexioa ezartzeko eta kontsultak egiteko erabiltzen da.
 */
public class DB {

    private String url;
    private String user;
    private String pass;

    /**
     * {@code DB} klaseko defektuzko eraikitzailea.
     * Konexioa lokaletik egiten da Oracle datu basea erabiltzen duen bidez.
     * Erabiltzailea: ERRONKA
     * Pasahitza: 1234
     */
    public DB() {
        this.url = "jdbc:oracle:thin:@localhost:1521/xe";
        this.user = "ERRONKA";
        this.pass = "1234";
    }

    /**
     * {@code DB} klaseko eraikitzailea, parametrotzat.
     * 
     * @param url   datu basearen URL-a
     * @param user  datu basearen erabiltzailea
     * @param pass  datu basearen pasahitza
     */
    public DB(String url, String user, String pass) {
        this.url = url;
        this.user = user;
        this.pass = pass;
    }

    /**
     * Konexioa sortzeko metodoa.
     * 
     * @return konexio objektua
     */
    public Connection konexioa() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, user, pass);
            return conn;
        } catch (Exception e) {
            System.out.println("Konexio errorea: " + e);
        }
        return conn;
    }

    /**
     * Taulan dagoen gehieneko ID-a lortzen duen metodoa.
     * 
     * @param table  ID-a lortu nahi den taula
     * @return taulan dagoen gehieneko ID-a + 1
     */
    public int getMaxId(String table) {
        int auxId = 0;
        try {
            Connection conn = konexioa();
            String sql = "SELECT MAX(ID) as a FROM " + table;
            PreparedStatement pS = conn.prepareStatement(sql);
            ResultSet rs = pS.executeQuery();
            if (rs.next()) {
                auxId = rs.getInt("a");
            }
            // konexioak itxi
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }
        return auxId + 1;
    }

    /**
     * Erabiltzailea sartzen denean ID-a itzultzen duen metodoa (bezeroentzako).
     * 
     * @param erabil   erabiltzailearen izena
     * @param pasahitz erabiltzailearen pasahitza
     * @return erabiltzailearen ID-a
     */
    public int getIdFromErabilBezeroa(String erabil, String pasahitz) {
        int auxId = 0;
        try {
            Connection conn = konexioa();
            String sql = "{ ? = call F_BEZERO_SARTU(?, ?) }";
            CallableStatement stmt = conn.prepareCall(sql);
            stmt.registerOutParameter(1, Types.INTEGER);
            stmt.setString(2, erabil);
            stmt.setString(3, pasahitz);
            stmt.execute();
            auxId = stmt.getInt(1);
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return auxId;
    }

    /**
     * Erabiltzailea sartzen denean ID-a itzultzen duen metodoa (saltzaileentzako).
     * 
     * @param erabil   erabiltzailearen izena
     * @param pasahitz erabiltzailearen pasahitza
     * @return erabiltzailearen ID-a
     */
    public int getIdFromErabilSaltzailea(String erabil, String pasahitz) {
        int auxId = 0;
        try {
            Connection conn = konexioa();
            CallableStatement stmt = conn.prepareCall("{ call P_SALTZAILE_SARTU(?, ?, ?) }");
            stmt.setString(1, erabil);
            stmt.setString(2, pasahitz);
            stmt.registerOutParameter(3, Types.INTEGER);
            stmt.execute();
            auxId = stmt.getInt(3);
            conn.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erabiltzailea edo pasahitza txarto sartu duzu");
        }
        return auxId;
    }
    
    /**
     * Bezero berria gehitzeko metodoa.
     * 
     * @param id        bezeroaren ID-a
     * @param izena     bezeroaren izena
     * @param abizena   bezeroaren abizena
     * @param helbidea  bezeroaren helbidea
     * @param emaila    bezeroaren emaila
     */
    public void gehituBezero(int id, String izena, String abizena, String helbidea, String emaila){
        //Prepare statement
        String insertSQL = "INSERT INTO BEZERO(ID, IZENA, ABIZENA, HELBIDEA, EMAILA) VALUES (?, ?, ?, ?, ?)";
        try{
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement(insertSQL);
            pS.setInt(1, id);
            pS.setString(2, izena);
            pS.setString(3, abizena);         
            pS.setString(4, helbidea);
            pS.setString(5, emaila);
            pS.executeUpdate();                                                                                          
        }catch(SQLException e){
            System.out.println("ERROREA: " + e);
        }  
    }
    
    /**
     * Bezeroaren telefonoa gehitzeko metodoa.
     * 
     * @param id        bezeroaren ID-a
     * @param zenbakia  telefono zenbakia
     */
    public void gehituBezeroTelefonoa(int id, String zenbakia){
        //Prepare statement
        String insertSQL = "INSERT INTO BEZERO_TELEFONO(ID, ID_BEZERO, ZENBAKIA) VALUES (?, ?, ?)";
        try{
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement(insertSQL);
            pS.setInt(1, 1);
            pS.setInt(2, id);
            pS.setString(3, zenbakia);
            pS.executeUpdate();                                                                                          
        }catch(SQLException e){
            System.out.println("ERROREA: " + e);
        }  
    }
    
    /**
     * Bezeroen informazioa kargatzeko eta ateratzeko metodoa.
     * 
     * @return bezeroen objektuak
     */
    public Bezeroak bezeroak (){
        Bezeroak bDB = new Bezeroak();     
        try {
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement("SELECT ID, IZENA, ABIZENA FROM BEZERO");
            ResultSet rs = pS.executeQuery();
            while (rs.next()) {
                Bezeroa aux = new Bezeroa (rs.getInt("ID"),rs.getString("IZENA"), rs.getString("ABIZENA"));
                bDB.addBezeroak(aux);
            }
            //konexioak itxi
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }   
        return bDB;
    }
    
    /**
     * Bezeroaren taulako informazioa lortzeko metodoa.
     * 
     * @param colum taulako zutabearen izena
     * @param id    bezeroaren ID-a
     * @return      bezeroaren taulako zutabearen balioa
     */
    public String getInfoBezeroTable (String colum, int id){
        String aux = "";
        try {
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement("SELECT " + colum + " AS A FROM BEZERO WHERE ID = ?");    
            pS.setInt(1, id);
            ResultSet rs = pS.executeQuery();
            if (rs.next()) {
                aux=rs.getString("A");
            }
            //konexioak itxi
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }   
        return aux;
    }
    /**
     * Bezeroaren telefonoa lortzeko metodoa.
     * 
     * @param id    bezeroaren ID-a
     * @return      telefono zenbakia
     */
    public String getInfoBezeroTeleTable ( int id){
        String aux = "";
        try {
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement("SELECT ZENBAKIA FROM BEZERO_TELEFONO WHERE ID_BEZERO = ?");
            pS.setInt(1, id);
            ResultSet rs = pS.executeQuery();
            if (rs.next()) {
                aux=rs.getString("ZENBAKIA");
            }
            //konexioak itxi
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }   
        return aux;
    }
    
    /**
     * Bezeroaren taulako informazioa eguneratzeko metodoa.
     * 
     * @param id        bezeroaren ID-a
     * @param izena     bezeroaren izena
     * @param abizena   bezeroaren abizena
     * @param helbidea  bezeroaren helbidea
     * @param emaila    bezeroaren emaila
     */
    public void eguneratuBezeroaTable (int id, String izena, String abizena,String helbidea, String emaila){
        //Prepare statement
        String updateSQL = "UPDATE BEZERO SET IZENA = ?, ABIZENA = ?, HELBIDEA = ?, EMAILA = ? WHERE ID = ?";
        try{
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement(updateSQL);
            pS.setString(1, izena);
            pS.setString(2, abizena);         
            pS.setString(3, helbidea);
            pS.setString(4, emaila);
            pS.setInt(5, id);
            pS.executeUpdate();   
            conn.close();
            pS.close();
        }catch(SQLException e){
            System.out.println("ERROREA: " +e);
        } 
    }
    
    /**
     * Bezeroaren telefonoa eguneratzeko metodoa.
     * 
     * @param id        bezeroaren ID-a
     * @param zenbakia  telefono zenbakia
     */
    public void eguneratuBezeroaTeleTable (int id, String zenbakia){
        //Prepare statement
        String updateSQL = "UPDATE BEZERO_TELEFONO SET ZENBAKIA = ? WHERE ID_BEZERO = ?";
        try{
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement(updateSQL);
            pS.setString(1, zenbakia);
            pS.setInt(2, id);
            pS.executeUpdate();
            conn.close();
            pS.close();
        }catch(SQLException e){
            System.out.println("ERROREA: " +e);
        } 
    }
    
    /**
     * Bezeroa taulatik ezabatzeko metodoa.
     * 
     * @param id    bezeroaren ID-a
     */
    public void bezeroEzabatuTable(int id) {
        try {
            Connection conn = konexioa(); 
            String deleteSQL = "DELETE FROM BEZERO WHERE id = ?";
            PreparedStatement pS = conn.prepareStatement(deleteSQL);
            pS.setInt(1, id);
            pS.executeUpdate();    
            // Konexioa itxi eta PreparedStatement
            pS.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Errorea bezeroa ezabatzerakoan: " + e.getMessage());
        }
    }
    /**
     * Bezeroaren telefonoa taulatik ezabatzeko metodoa.
     * 
     * @param id    bezeroaren ID-a
     */
    public void bezeroEzabatuTeleTable(int id) {
        try {
            Connection conn = konexioa(); 
            String deleteSQL = "DELETE FROM BEZERO_TELEFONO WHERE ID_BEZERO = ?";
            PreparedStatement pS = conn.prepareStatement(deleteSQL);
            pS.setInt(1, id);
            pS.executeUpdate();        
            // Konexioa itxi eta PreparedStatement
            pS.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Errorea bezeroaren telefonoa ezabatzerakoan: " + e.getMessage());
        }
    }
    
    /**
     * Bezeroaren ID-a izena eta abizena erabiliz lortzeko metodoa.
     * 
     * @param izena     bezeroaren izena
     * @param abizena   bezeroaren abizena
     * @return          bezeroaren ID-a
     */
    public int getIdFromIzenBezero(String izena, String abizena){
        int aux = 0;
        try {
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement("SELECT ID FROM BEZERO WHERE IZENA = ? AND ABIZENA = ?");   
            pS.setString(1, izena);
            pS.setString(2, abizena);
            ResultSet rs = pS.executeQuery();
            if (rs.next()) {
                aux=rs.getInt("ID");
            }
            //konexioak itxi
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }   
        return aux;
    }
    
    /**
     * Produktuak taulatik informazioa kargatzeko eta lortzeko metodoa.
     * 
     * @return  produktuak
     */
    public Produktuak produktuak (){
        Produktuak bDB = new Produktuak();        
        try {
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement("SELECT ID, IZENA FROM PRODUKTU");
            ResultSet rs = pS.executeQuery();
            while (rs.next()) {        
                Produktua aux = new Produktua (rs.getInt("ID"),rs.getString("IZENA"));               
                bDB.addProduktuak(aux);
            }
            //konexioak itxi
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }   
        return bDB;
    }
    
    /**
     * Produktuak taulako informazioa kargatzeko eta filtratzeko metodoa.
     * 
     * @param min       produktuaren salneurri baxuena
     * @param max       produktuaren salneurri handiena
     * @param kategoria produktuaren kategoria
     * @return          produktuak
     */
    public Produktuak produktuakFiltratu(int min, int max, String kategoria){
        Produktuak bDB = new Produktuak();        
        try {
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement("SELECT PRODUKTU.ID, PRODUKTU.IZENA FROM PRODUKTU JOIN KATEGORIA ON PRODUKTU.ID_KATEGORIA = KATEGORIA.ID WHERE PRODUKTU.SALNEURRIA >= ? AND PRODUKTU.SALNEURRIA <= ? AND KATEGORIA.IZENA = ?");
            pS.setInt(1, min);
            pS.setInt(2, max);
            pS.setString(3, kategoria);
            ResultSet rs = pS.executeQuery();
            while (rs.next()) {        
                Produktua aux = new Produktua (rs.getInt("ID"),rs.getString("IZENA"));               
                bDB.addProduktuak(aux);
            }
            //konexioak itxi
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }   
        return bDB;
    }
    /**
     * Produktuaren taulatik informazioa eskuratzeko metodoa.
     * 
     * @param colum     lortu nahi den zutabeko izena
     * @param id        produktuaren ID-a
     * @return          zutabearen balioa
     */
    public String getInfoProduktuTable(String colum, int id){
        String aux = "";
        try {
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement("SELECT " + colum + " AS A FROM PRODUKTU WHERE ID = ?");    
            pS.setInt(1, id);
            ResultSet rs = pS.executeQuery();
            if (rs.next()) {
                aux=rs.getString("A");
            }
            //konexioak itxi
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }   
        return aux;
    }
    
    /**
     * Produktuaren kategoria informazioa eskuratzeko metodoa.
     * 
     * @param id    produktuaren ID-a
     * @return      kategoria izena
     */
    public String getInfoKategoria(int id){
        String aux = "";
        try {
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement("SELECT KATEGORIA.IZENA AS A FROM KATEGORIA JOIN PRODUKTU ON KATEGORIA.ID = PRODUKTU.ID_KATEGORIA WHERE PRODUKTU.ID=?");    
            pS.setInt(1, id);
            ResultSet rs = pS.executeQuery();
            if (rs.next()) {
                aux=rs.getString("A");
            }
            //konexioak itxi
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }   
        return aux;
    }
    
    /**
     * Produktuaren stock informazioa eskuratzeko metodoa.
     * 
     * @param id    produktuaren ID-a
     * @return      produktuaren stock-aren totala
     */
    public String getInfoStock(int id){
        String aux = "";
        try {
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement("SELECT SUM(KOPURUA) AS A FROM INBENTARIO WHERE ID_PRODUKTU = ?");    
            pS.setInt(1, id);
            ResultSet rs = pS.executeQuery();
            if (rs.next()) {
                aux=rs.getString("A");
            }
            //konexioak itxi
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }   
        return aux;
    }
    
    /**
     * Produktuaren taularen informazioa eguneratzeko metodoa.
     * 
     * @param idSele        eguneratu nahi den produktuaren ID-a
     * @param izena         produktuaren izena
     * @param desk          produktuaren deskribapena
     * @param balioa        produktuaren balioa
     * @param salneurria    produktuaren salneurria
     * @param kategoria     produktuaren kategoria
     * @throws SQLException    SQL errorea
     */
    public void eguneratuProduktuTable(int idSele, String izena, String desk, double balioa, double salneurria, int kategoria) throws SQLException {
        String kont = "UPDATE PRODUKTU SET IZENA = ?, DESKRIBAPENA = ?, BALIOA = ?, SALNEURRIA = ? ,ID_KATEGORIA = ? WHERE ID = ?";
        Connection conn = konexioa();
        try (PreparedStatement pstmt = conn.prepareStatement(kont)) {
            pstmt.setString(1, izena);
            pstmt.setString(2, desk);
            pstmt.setDouble(3, balioa);
            pstmt.setDouble(4, salneurria);
            pstmt.setInt(5, kategoria);
            pstmt.setInt(6, idSele);
            pstmt.executeUpdate();
            //konexioa eta PreparedStatement itxi
            pstmt.close();
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw ex;
        }
    }
    /**
     * Produktuaren IDa lortzeko metodoa izenaren arabera.
     * 
     * @param izena     produktuaren izena
     * @return          produktuaren IDa
     */
    public int getIdFromIzenProduktu(String izena){
        int aux = 0;
        try {
            Connection conn = konexioa();
            PreparedStatement pS = conn.prepareStatement("SELECT ID FROM PRODUKTU WHERE IZENA = ?");    
            pS.setString(1, izena);
            ResultSet rs = pS.executeQuery();
            if (rs.next()) {
                aux=rs.getInt("ID");
            }
            conn.close();
            pS.close();
            rs.close();
        } catch (SQLException e) {
            System.out.println("ERROREA: " + e);
        }   
        return aux;
    }
    
    /**
     * Produktua ezabatzeko metodoa.
     * 
     * @param id    ezabatu nahi den produktuaren IDa
     */
    public void produktuEzabatu(int id) {
        try {
            Connection conn = konexioa(); 
            String deleteProduktuoSql = "DELETE FROM PRODUKTU WHERE id = ?";
            PreparedStatement pstmtDeleteProd = conn.prepareStatement(deleteProduktuoSql);
            pstmtDeleteProd.setInt(1, id);
            pstmtDeleteProd.executeUpdate();    
            // PreparedStatement itxi
            pstmtDeleteProd.close();
            conn.close();
        } catch (SQLException e) {
            System.out.println("Arazo bat egon da produktua ezabatzeko: " + e.getMessage());
        }
    }
    
    /**
     * Produktua erositzeko metodoa.
     * 
     * @param pId       produktuaren IDa
     * @param pKopuru   erosteko kopurua
     * @param bId       bezeroaren IDa
     */
    public void produktuErosi(int pId, int pKopuru, int bId) {
        try (Connection conn = konexioa(); ) {
            CallableStatement cs = conn.prepareCall("{call p_erosi(?, ?, ?)}");
            cs.setInt(1, pId);
            cs.setInt(2, pKopuru);
            cs.setInt(3, bId);
            cs.execute();
            //konexioa eta CallableStatement itxi
            conn.close();
            cs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
