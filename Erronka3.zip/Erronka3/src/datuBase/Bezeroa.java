package datuBase;

/**
 * {@code Bezeroa} klaseak bezeroen informazioa gordetzen du, hau da,
 * bezeroaren ID-a, izena eta abizena.
 */
public class Bezeroa {
    private int id;
    private String izena;
    private String abizena;
    
    /**
     * {@code Bezeroa} klaseko konstruktorea.
     * 
     * @param id bezeroaren ID-a
     * @param izena bezeroaren izena
     * @param abizena bezeroaren abizena
     */
    public Bezeroa(int id, String izena, String abizena) {
        super();
        this.id = id;
        this.izena = izena;
        this.abizena = abizena;
    }
    
    /**
     * Bezeroaren ID-a bueltatzen du.
     * 
     * @return bezeroaren ID-a
     */
    public int getId() {
        return id;
    }
    
    /**
     * Bezeroaren izena bueltatzen du.
     * 
     * @return bezeroaren izena
     */
    public String getIzena() {
        return izena;
    }
    
    /**
     * Bezeroaren abizena bueltatzen du.
     * 
     * @return bezeroaren abizena
     */
    public String getAbizena() {
        return abizena;
    }
    
    /**
     * Bezeroaren ID-a ezarri.
     * 
     * @param id bezeroaren ID-a
     */
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * Bezeroaren izena ezarri.
     * 
     * @param izena bezeroaren izena
     */
    public void setIzena(String izena) {
        this.izena = izena;
    }
    
    /**
     * Bezeroaren abizena ezarri.
     * 
     * @param abizena bezeroaren abizena
     */
    public void setAbizena(String abizena) {
        this.abizena = abizena;
    }
    
    /**
     * Bezeroaren informazioa string formatuan itzultzen du.
     * 
     * @return bezeroaren informazioa
     */
    @Override
    public String toString() {
        return  izena + " " + abizena;
    }
}
