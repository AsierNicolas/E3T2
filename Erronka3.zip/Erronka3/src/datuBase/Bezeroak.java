package datuBase;

import java.util.Arrays;

/**
 * {@code Bezeroak} klaseak bezeroen informazioa kudeatzen du.
 * Bezeroen zerrenda bat gordetzen du eta bezero berriak gehitzeko,
 * zerrendako bezeroak lortzeko eta bezero baten ID-a lortzeko metodoak
 * eskaintzen ditu.
 */
public class Bezeroak {
    private Bezeroa[] bezeroak;

    /**
     * {@code Bezeroak} klaseko konstruktorea.
     * Bezeroen zerrenda hutsa sortzen du.
     */
    public Bezeroak() {
        bezeroak = new Bezeroa[0];
    }

    /**
     * Bezero berri bat zerrendan gehitzen du.
     * 
     * @param bezeroa gehitu nahi den bezeroa
     */
    public void addBezeroak(Bezeroa bezeroa) {
        this.bezeroak = Arrays.copyOf(this.bezeroak, this.bezeroak.length + 1);
        this.bezeroak[this.bezeroak.length - 1] = bezeroa;
    }

    /**
     * Zerrendan dauden bezeroak bueltatzen ditu.
     * 
     * @return zerrendako bezeroen arraya
     */
    public Bezeroa[] getBezeroakList() {
        return bezeroak;
    }

    /**
     * Zerrendako bezeroen bat emandako indizean bueltatzen du.
     * 
     * @param index bezeroaren indizea zerrendan
     * @return bezeroa
     */
    public Bezeroa getBezeroa(int index) {
        return this.bezeroak[index];
    }

    /**
     * Zerrendako bezero baten ID-a bueltatzen du.
     * 
     * @param index bezeroaren indizea zerrendan
     * @return bezeroaren ID-a
     */
    public int getBezeroId(int index) {
        return this.bezeroak[index].getId();
    }

    /**
     * Zerrendako bezeroen informazioa pantailaratzen du.
     */
    public void getBezeroak() {
        for (int i = 0; i < this.bezeroak.length; i++) {
            System.out.println(bezeroak[i].toString());
        }
    }

    /**
     * Bezeroen informazioa karaktere kate gisa itzultzen du.
     * 
     * @return bezeroen informazioa
     */
    public String toString() {
        String all = "";
        for (int i = 0; i < this.bezeroak.length; i++) {
            all += bezeroak[i].toString() + "\n";
        }
        return all;
    }
}
