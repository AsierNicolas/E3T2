package datuBase;

/**
 * {@code Produktua} klaseak produktuen informazioa gordetzen du, hau da,
 * produktuaren ID-a eta izena.
 */
public class Produktua {
    private int id;
    private String izena;
    
    /**
     * {@code Produktua} klaseko konstruktorea.
     * 
     * @param id produktuaren ID-a
     * @param izena produktuaren izena
     */
    public Produktua(int id, String izena) {
        super();
        this.id = id;
        this.izena = izena;
    }

    /**
     * Produktuaren ID-a bueltatzen du.
     * 
     * @return produktuaren ID-a
     */
    public int getId() {
        return id;
    }

    /**
     * Produktuaren izena bueltatzen du.
     * 
     * @return produktuaren izena
     */
    public String getIzena() {
        return izena;
    }

    /**
     * Produktuaren ID-a ezartzen du.
     * 
     * @param id produktuaren ID-a
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Produktuaren izena ezartzen du.
     * 
     * @param izena produktuaren izena
     */
    public void setIzena(String izena) {
        this.izena = izena;
    }
    
    /**
     * Produktuaren informazioa string formatuan itzultzen du.
     * 
     * @return produktuaren informazioa
     */
    @Override
    public String toString() {
        return  izena;
    }
}
