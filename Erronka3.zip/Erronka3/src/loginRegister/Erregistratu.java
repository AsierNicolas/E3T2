package loginRegister;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import datuBase.DB;

/**
 * Erregistratu klaseak erabiltzaileak erregistratzeko interfazea erakusten duen klasea da.
 * Erabiltzaileak izen, abizen, helbide, email eta telefono zenbakia sartu behar ditu.
 */
public class Erregistratu extends JDialog {
    private static final long serialVersionUID = 1L;

    private JLabel izenaLabel = new JLabel("IZENA:");
    private JLabel abizenaLabel = new JLabel("ABIZENA:");
    private JLabel helbideaLabel = new JLabel("HELBIDEA:");
    private JLabel emailaLabel = new JLabel("EMAILA:");
    private JLabel telefonoaLabel = new JLabel("TELEFONOA:");

    private JTextField izenaField = new JTextField(10);
    private JTextField abizenaField = new JTextField(10);
    private JTextField helbideaField = new JTextField(10);
    private JTextField emailaField = new JTextField(10);
    private JTextField telefonoaField = new JTextField(10);

    private JButton bAtzera = new JButton("ATZERA");
    private JButton bErreg = new JButton("ERREGISTRATU");

    /**
     * Erregistratu klasearen eraikitzailea.
     * Erregistro interfazea eta ekintza botoiak konfiguratzen ditu.
     */
    public Erregistratu() {
        JPanel panel = new JPanel(new GridLayout(5, 2));
        panel.add(izenaLabel);
        panel.add(izenaField);
        panel.add(abizenaLabel);
        panel.add(abizenaField);
        panel.add(helbideaLabel);
        panel.add(helbideaField);
        panel.add(emailaLabel);
        panel.add(emailaField);
        panel.add(telefonoaLabel);
        panel.add(telefonoaField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(bAtzera);
        buttonPanel.add(bErreg);

        JPanel mainPanel = new JPanel();
        mainPanel.add(panel);
        mainPanel.add(buttonPanel);

        this.getContentPane().add(mainPanel);
        this.setSize(300, 200);

        // Ekintza entzuleak
        bErreg.addActionListener(e -> erregistratuBezeroa());
        bAtzera.addActionListener(e -> atzera());
    }

    /**
     * Erabiltzailea datu-basean erregistratzen duen metodoa.
     * Erabiltzaileak sartutako datuak datu-basean gordetzen ditu.
     */
    private void erregistratuBezeroa() {
        int opcion = JOptionPane.showConfirmDialog(null, "Ondo sartu dituzu datuak?", "", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            DB db = new DB();
            int auxId = db.getMaxId("BEZERO");
            db.gehituBezero(auxId, izenaField.getText(), abizenaField.getText(), helbideaField.getText(), emailaField.getText());
            db.gehituBezeroTelefonoa(auxId, telefonoaField.getText());

            JOptionPane.showMessageDialog(null, "Erregistratu zara. Hasi saioa sartzeko, mesedez.");
            atzera();
        }
    }

    /**
     * Atzerako botoiak sakatzean saio hasierako interfazea erakusten duen metodoa.
     */
    private void atzera() {
        this.dispose();
        Login login = new Login();
        login.setLocationRelativeTo(null);
        login.setVisible(true);
    }
}
