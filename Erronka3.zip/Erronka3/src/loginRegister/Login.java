package loginRegister;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import bezeroPant.BezeroPant;
import datuBase.DB;
import saltzailePant.SaltzailePant;

/**
 * Saio hasierako interfazea erakusten duen klasea.
 * Erabiltzaileek sartutako erabiltzaile-izen eta pasahitza-abizena baliatzen ditu
 * saioa hasteko, bestalde bezero berria erregistratzeko.
 */
public class Login extends JFrame {
    private static final long serialVersionUID = 1L;
    
    private DB db = new DB();
    
    // JLabel-ak
    private JLabel erabilLabel = new JLabel("ERABILTZAILEA:");
    private JLabel passLabel = new JLabel("PASAHITZA:");
    
    // JTextFields
    private JTextField tErabil = new JTextField("", 10);
    private JTextField tPass = new JTextField("", 10);
    
    // Botoiak
    private JButton bLogin = new JButton("SAIOA HASTEA");
    private JButton bErreg = new JButton("ERREGISTRATU");
    
    // Panelak
    private JPanel pPanel = new JPanel();
    private JPanel panel = new JPanel(new GridLayout(2, 2));
    private JPanel pBotoiak = new JPanel();

    // Bezero edo Saltzaile id
    private int id;
    
    /**
     * Login klasearen eraikitzailea.
     * Saio hasiera interfazea eta ekintza botoiak konfiguratzen ditu.
     */
    public Login() {
        String tabla = "bezero";
        db.getMaxId(tabla);
        
        // Panel-en konfigurazioa
        panel.add(erabilLabel);
        panel.add(tErabil);
        panel.add(passLabel);
        panel.add(tPass);
        pBotoiak.add(bLogin);
        pBotoiak.add(bErreg);     
        pPanel.add(panel);
        pPanel.add(pBotoiak);

        // JFrame-aren konfigurazioa
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().add(pPanel);
        this.setSize(300, 140);
        
        // Ekintza entzuleak
        bErreg.addActionListener(e -> erregistratuBezeroa());
        bLogin.addActionListener(e -> login());
    }
    
    /**
     * Erabiltzailea erregistratzeko metodoa.
     * Erregistratu klasearen instantzia bat sortzen du eta erakusten du.
     */
    private void erregistratuBezeroa() {
        this.dispose();
        Erregistratu erregistratu = new Erregistratu();
        erregistratu.setLocationRelativeTo(null);
        erregistratu.setVisible(true);
    }
    
    /**
     * Saioa hasteko metodoa.
     * Erabiltzaile-izen eta pasahitza-abizena balidatzen ditu, eta erabiltzailea
     * bezeroa edo saltzailea den arabera pantaila zuzena irekitzen du.
     */
    private void login() {
        id = db.getIdFromErabilBezeroa(tErabil.getText(), tPass.getText());
        if (id == 0) {
            id = db.getIdFromErabilSaltzailea(tErabil.getText(), tPass.getText());
            if (id == 0) {
                tErabil.setText("");
                tPass.setText("");
            } else {
                this.dispose();
                SaltzailePant saltzailePant = new SaltzailePant();
                saltzailePant.setLocationRelativeTo(null);
                saltzailePant.setVisible(true);
            }
        } else {
            this.dispose();
            BezeroPant bezeroPant = new BezeroPant(id, 0, 1000, "*");
            bezeroPant.setLocationRelativeTo(null);
            bezeroPant.setVisible(true);
        }
    }
}