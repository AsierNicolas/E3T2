package saltzailePant;

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import bezeroPant.BezeroDatuakAldatu;
import datuBase.Bezeroak;
import datuBase.DB;
import loginRegister.Login;

/**
 * Saltzaileek bezero lista ikusteko eta informazioa aldatu eta ezabatzeko leihoa.
 */
public class BezeroAldaketaPant extends JFrame {

    private static final long serialVersionUID = 1L;
    private static DB datuBase;
    private static int idSele;
    private JComboBox<String> comboBox;
    private Bezeroak bezeroak;

    private JLabel vacio1;
    private JLabel vacio2;
    private JLabel izena1;
    private JLabel abizena1;
    private JLabel helbidea1;
    private JLabel emaila1;
    private JLabel zenbakia1;
    private JLabel izena2;
    private JLabel abizena2;
    private JLabel helbidea2;
    private JLabel emaila2;
    private JLabel zenbakia2;

    /**
     * BezeroAldaketaPant klasearen eraikitzailea.
     */
    public BezeroAldaketaPant() {

        // Database initialization
        datuBase = new DB();
        bezeroak = datuBase.bezeroak();
        idSele = bezeroak.getBezeroId(0);

        // JLabels initialization
        vacio1 = new JLabel("                                                                ");
        vacio2 = new JLabel("                                                                ");
        izena1 = new JLabel("IZENA");
        abizena1 = new JLabel("ABIZENA:");
        helbidea1 = new JLabel("HELBIDEA:");
        emaila1 = new JLabel("EMAILA:");
        zenbakia1 = new JLabel("ZENBAKIA:");
        izena2 = new JLabel(datuBase.getInfoBezeroTable("IZENA", bezeroak.getBezeroId(0)));
        abizena2 = new JLabel(datuBase.getInfoBezeroTable("ABIZENA", bezeroak.getBezeroId(0)));
        helbidea2 = new JLabel(datuBase.getInfoBezeroTable("HELBIDEA", bezeroak.getBezeroId(0)));
        emaila2 = new JLabel(datuBase.getInfoBezeroTable("EMAILA", bezeroak.getBezeroId(0)));
        zenbakia2 = new JLabel(datuBase.getInfoBezeroTeleTable(bezeroak.getBezeroId(0)));

        // JButton initialization
        JButton bEzabatu = new JButton("EZABATU");
        JButton bEguneratu = new JButton("EGUNERATU");

        // JComboBox initialization
        comboBox = new JComboBox<>();
        for (int i = 0; i < bezeroak.getBezeroakList().length; i++) {
            comboBox.addItem(bezeroak.getBezeroakList()[i].toString());
        }

        // Panel initialization
        JPanel panel = new JPanel();
        panel.add(vacio1);
        panel.add(bEzabatu);
        panel.add(comboBox);
        panel.add(bEguneratu);
        panel.add(vacio2);
        
        JPanel pDatuak1 = new JPanel(new GridLayout(5, 1));
        JPanel pDatuak2 = new JPanel(new GridLayout(5, 1));
        pDatuak1.setPreferredSize(new Dimension(200, 110));
        pDatuak2.setPreferredSize(new Dimension(200, 110));
        pDatuak1.add(izena1);
        pDatuak2.add(izena2);
        pDatuak1.add(abizena1);
        pDatuak2.add(abizena2);
        pDatuak1.add(helbidea1);
        pDatuak2.add(helbidea2);
        pDatuak1.add(emaila1);
        pDatuak2.add(emaila2);
        pDatuak1.add(zenbakia1);
        pDatuak2.add(zenbakia2);

        // JMenuBar initialization
        JMenu menu = new JMenu("BEZERO LISTA");
        JMenuBar jmb = new JMenuBar();
        jmb.add(menu);
        JMenuBar menuBar = new JMenuBar();
        JMenuItem bProduktuLista = new JMenuItem("PRODUKTU LISTA");
        JMenuItem bSaioaItxi = new JMenuItem("SAIOA ITXI");
        menu.add(bProduktuLista);
        menu.add(bSaioaItxi);

        // JPanel initialization
        JPanel pPaneles = new JPanel();
        pPaneles.add(menuBar);
        pPaneles.add(panel);
        pPaneles.add(pDatuak1);
        pPaneles.add(pDatuak2);

        // JFrame initialization
        this.setTitle("SALTZAILE");
        this.setJMenuBar(jmb);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().add(pPaneles);
        this.setSize(500, 250);

        // ActionListeners initialization
        comboBox.addActionListener(e -> {
            String elementoSele = (String) comboBox.getSelectedItem();
            String[] partes = elementoSele.split(" ");
            String izena = partes[0];
            String abizena = partes[1];
            idSele = datuBase.getIdFromIzenBezero(izena, abizena);
            izena2.setText(datuBase.getInfoBezeroTable("IZENA", idSele));
            abizena2.setText(datuBase.getInfoBezeroTable("ABIZENA", idSele));
            helbidea2.setText(datuBase.getInfoBezeroTable("HELBIDEA", idSele));
            emaila2.setText(datuBase.getInfoBezeroTable("EMAILA", idSele));
            zenbakia2.setText(datuBase.getInfoBezeroTeleTable(idSele));
        });

        bProduktuLista.addActionListener(e -> bProduktuListaJOption(this));
        bSaioaItxi.addActionListener(e -> bSaioaItxiJOption(this));

        bEzabatu.addActionListener(e -> bBezeroEzabatu());
        bEguneratu.addActionListener(e -> bBezeroEguneratu());
    }

    /**
     * Bezeroaren informazioa eguneratzeko metodoa.
     */
    private void bBezeroEguneratu() {
        this.dispose();
        BezeroDatuakAldatu a = new BezeroDatuakAldatu(idSele, 0, 10000, "saltzaile");
        a.setLocationRelativeTo(null);
        a.setVisible(true);
    }

    /**
     * Bezeroa ezabatzeko metodoa.
     */
    private void bBezeroEzabatu() {
        this.dispose();
        int opcion = JOptionPane.showConfirmDialog(null, "Aukeratutako bezeroa ezabatu nahi duzu?", "",
                JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            System.out.println(idSele);
            datuBase.bezeroEzabatuTeleTable(idSele);
            datuBase.bezeroEzabatuTable(idSele);
            BezeroAldaketaPant a = new BezeroAldaketaPant();
            a.setLocationRelativeTo(null);
            a.setVisible(true);
        } else {
            BezeroAldaketaPant a = new BezeroAldaketaPant();
            a.setLocationRelativeTo(null);
            a.setVisible(true);
        }
    }

    /**
     * Produktu listako botoiak sakatu eta ProduktuAldaketaPant klasean sartzen duen metodoa.
     */
    private static void bProduktuListaJOption(BezeroAldaketaPant frame) {
        frame.dispose();
        ProduktuAldaketaPant a = new ProduktuAldaketaPant(0, 0, 10000, "*");
        a.setLocationRelativeTo(null);
        a.setVisible(true);
    }

    /**
     * Saioa itxi nahi duen botoia sakatu eta Login klasean sartzen duen metodoa.
     */
    private static void bSaioaItxiJOption(BezeroAldaketaPant frame) {
        frame.dispose();
        int opcion = JOptionPane.showConfirmDialog(null, "Saioa itxi nahi duzu?", "", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            Login login = new Login();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        } else {
            frame.setVisible(true);
        }
    }
}
