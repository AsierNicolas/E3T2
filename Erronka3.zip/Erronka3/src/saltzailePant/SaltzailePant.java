package saltzailePant;

import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import loginRegister.Login;

/**
 * {@code SaltzailePant} klaseak saltzailearen pantaila grafikoa sortzen du.
 * Pantaila honetan bezeroen eta produktuen zerrendak bistaratu eta saioa ixteko
 * aukera ematen dira.
 */
public class SaltzailePant extends JFrame {

    private static final long serialVersionUID = 1L;

    /**
     * SaltzailePant klasearen eraikitzailea.
     * Pantailako botoiak sortzen ditu eta hauen funtzionalitateak definitzen dira.
     */
    public SaltzailePant () {
        JButton bBezeroLista  = new JButton("BEZERO LISTA");
        JButton bProduktuLista  = new JButton("PRODUKTU LISTA");
        JButton bSaioaItxi  = new JButton("SAIOA ITXI");

        Dimension buttonSize = new Dimension(200, 50);
        bBezeroLista.setPreferredSize(buttonSize);
        bProduktuLista.setPreferredSize(buttonSize);
        bSaioaItxi.setPreferredSize(buttonSize);
        
        JPanel pPanel = new JPanel();
        pPanel.add(bBezeroLista);
        pPanel.add(bProduktuLista);
        pPanel.add(bSaioaItxi);
        
        this.setTitle("SALTZAILE");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().add(pPanel);
        this.setSize(380,220);
        
        bBezeroLista.addActionListener(e -> bezeroLista(this));
        bProduktuLista.addActionListener(e -> produktuLista(this));
        bSaioaItxi.addActionListener(e -> saioaItxi(this));
    }

    /**
     * Saltzaileak bezeroen zerrenda ikusteko pantaila irekitzeko metodoa.
     * 
     * @param frame SaltzailePant klasearen instantzia.
     */
    public void bezeroLista(SaltzailePant frame) {
        frame.dispose();
        BezeroAldaketaPant a = new BezeroAldaketaPant();
        a.setLocationRelativeTo(null);
        a.setVisible(true);
    }

    /**
     * Saltzaileak produktuen zerrenda ikusteko pantaila irekitzeko metodoa.
     * 
     * @param frame SaltzailePant klasearen instantzia.
     */
    public void produktuLista(SaltzailePant frame) {
        frame.dispose();
        ProduktuAldaketaPant a = new ProduktuAldaketaPant(0, 0, 10000, "*");
        a.setLocationRelativeTo(null);
        a.setVisible(true);
    }

    /**
     * Saioa ixteko aukera ematen duen metodoa.
     * 
     * @param frame SaltzailePant klasearen instantzia.
     */
    public void saioaItxi(SaltzailePant frame) {
        frame.dispose();
        int opcion = JOptionPane.showConfirmDialog(null, "Saioa itxi nahi duzu?", "", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            Login login = new Login();
            login.setLocationRelativeTo(null);
            login.setVisible(true);
        } else {
            frame.setVisible(true);
        }
    }

}
