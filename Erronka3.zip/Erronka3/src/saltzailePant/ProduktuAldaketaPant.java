package saltzailePant;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import bezeroPant.Filtro;
import datuBase.DB;
import datuBase.Produktuak;
import loginRegister.Login;

/**
 * Saltzaileaak produktu lista ikusteko, ezabatzeko eta datuak aldatzeko aukerekin JFrame da.
 */
public class ProduktuAldaketaPant extends JFrame {

    private static final long serialVersionUID = 1L;
    static DB datuBase;
    static int idBezero;
    static int idSele;
    static int minSal;
    static int maxSal;
    static String kategori;
    JComboBox<String> comboBox;
    Produktuak produktuak;

    JLabel vacio1;
    JLabel vacio2;
    JLabel izena1;
    JLabel deskribapena1;
    JLabel kategoria1;
    JLabel stock1;
    JLabel balioa1;
    JLabel salneurria1;

    JLabel izena2;
    JLabel deskribapena2;
    JLabel kategoria2;
    JLabel stock2;
    JLabel balioa2;
    JLabel salneurria2;

    /**
     * ProduktuAldaketaPant klasearen eraikitzailea.
     */
    public ProduktuAldaketaPant(int id, int min, int max, String kategoria) {
        idBezero = id;
        minSal = min;
        maxSal = max;
        kategori = kategoria;
        datuBase = new DB();
        if (kategori.equals("*")) {
            produktuak = datuBase.produktuak();
        } else {
            produktuak = datuBase.produktuakFiltratu(min, max, kategoria);
        }
        idSele = produktuak.getProduktuId(0);

        // JLabel.
        vacio1 = new JLabel("                                                                ");
        vacio2 = new JLabel("                                                                ");
        izena1 = new JLabel("IZENA");
        deskribapena1 = new JLabel("DESKRIBAPENA:");
        kategoria1 = new JLabel("KATEGORIA:");
        stock1 = new JLabel("STOCK:");
        balioa1 = new JLabel("BALIOA:");
        salneurria1 = new JLabel("SALNEURRIA:");

        izena2 = new JLabel(datuBase.getInfoProduktuTable("IZENA", produktuak.getProduktuId(0)));
        deskribapena2 = new JLabel(datuBase.getInfoProduktuTable("DESKRIBAPENA", produktuak.getProduktuId(0)));
        kategoria2 = new JLabel(datuBase.getInfoKategoria(produktuak.getProduktuId(0)));
        stock2 = new JLabel(datuBase.getInfoStock(produktuak.getProduktuId(0)));
        balioa2 = new JLabel(datuBase.getInfoProduktuTable("BALIOA", produktuak.getProduktuId(0)) + "€");
        salneurria2 = new JLabel(datuBase.getInfoProduktuTable("SALNEURRIA", produktuak.getProduktuId(0)) + "€");

        // JButtun sortu
        JButton bFiltrar = new JButton("FILTRAR");
        JButton bEzabatu = new JButton("EZABATU");
        JButton bEguneratu = new JButton("EGUNERATU");

        // Crear un JComboBox y añadir los elementos
        comboBox = new JComboBox<>();
        for (int i = 0; i < produktuak.getProduktuList().length; i++) {
            comboBox.addItem(produktuak.getProduktuList()[i].toString());
        }

        // Panel sorto eta gehitu gauzak
        JPanel panel = new JPanel();
        panel.add(vacio1);
        panel.add(bFiltrar);
        panel.add(comboBox);
        panel.add(vacio2);
        JPanel pDatuak1 = new JPanel(new GridLayout(6, 1));
        JPanel pDatuak2 = new JPanel(new GridLayout(6, 1));
        pDatuak1.setPreferredSize(new Dimension(200, 110));
        pDatuak2.setPreferredSize(new Dimension(400, 110));
        pDatuak1.add(izena1);
        pDatuak2.add(izena2);
        pDatuak1.add(deskribapena1);
        pDatuak2.add(deskribapena2);
        pDatuak1.add(kategoria1);
        pDatuak2.add(kategoria2);
        pDatuak1.add(stock1);
        pDatuak2.add(stock2);
        pDatuak1.add(balioa1);
        pDatuak2.add(balioa2);
        pDatuak1.add(salneurria1);
        pDatuak2.add(salneurria2);
        JPanel pBotoi = new JPanel();
        pBotoi.add(bEzabatu);
        pBotoi.add(bEguneratu);

        // JMenu
        JMenu menu = new JMenu("PRODUKTU LISTA");
        JMenuBar jmb = new JMenuBar();
        jmb.add(menu);
        JMenuBar menuBar = new JMenuBar();
        JMenuItem bBezeroLista = new JMenuItem("BEZERO LISTA");
        JMenuItem bSaioaItxi = new JMenuItem("SAIOA ITXI");
        menu.add(bBezeroLista);
        menu.add(bSaioaItxi);

        // Paneles
        JPanel pPaneles = new JPanel();
        pPaneles.add(menuBar);
        pPaneles.add(panel);
        pPaneles.add(pDatuak1);
        pPaneles.add(pDatuak2);
        pPaneles.add(pBotoi);

        //JFrame
        this.setTitle("SALTZAILE");
        this.setJMenuBar(jmb);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().add(pPaneles);
        this.setSize(700, 270);

        // Combobox elementuak tratatzeko.
        comboBox.addActionListener(e -> {
            idSele = datuBase.getIdFromIzenProduktu((String) comboBox.getSelectedItem());
            izena2.setText(datuBase.getInfoProduktuTable("IZENA", idSele));
            deskribapena2.setText(datuBase.getInfoProduktuTable("DESKRIBAPENA", idSele));
            kategoria2.setText(datuBase.getInfoKategoria(idSele));
            stock2.setText(datuBase.getInfoStock(idSele));
            balioa2.setText(datuBase.getInfoProduktuTable("BALIOA", idSele) + "€");
            salneurria2.setText(datuBase.getInfoProduktuTable("SALNEURRIA", idSele) + "€");
        });

        bProduktuListaJOption(this, bBezeroLista);
        bSaioaItxiJOption(this, bSaioaItxi);

        bFiltrar.addActionListener(e -> filtar());
        bEguneratu.addActionListener(e -> eguneratu());
        bEzabatu.addActionListener(e -> ezabatu());
    }

    /**
     * Produktua ezabatzeko metodoa.
     */
    public void ezabatu() {
        int opcion = JOptionPane.showConfirmDialog(null, "Produktua ezabatu nahi duzu?", "", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            this.dispose();
            datuBase.produktuEzabatu(idSele);
            ProduktuAldaketaPant a = new ProduktuAldaketaPant(0, 0, 10000, "*");
            a.setLocationRelativeTo(null);
            a.setVisible(true);
        }
    }

    /**
     * Produktuaren informazioa eguneratzeko metodoa.
     */
    public void eguneratu() {
        this.dispose();
        ProduktuDatuakAldatu a = new ProduktuDatuakAldatu(idSele, minSal, maxSal, kategori);
        a.setLocationRelativeTo(null);
        a.setVisible(true);
    }

    /**
     * Produktuak filtratzeko metodoa.
     */
    public void filtar() {
        this.dispose();
        Filtro a = new Filtro(idBezero, minSal, maxSal, kategori);
        a.setLocationRelativeTo(null);
        a.setVisible(true);
    }

    /**
     * Bezero lista pantaila irekitzeko metodoa.
     */
    public static void bProduktuListaJOption(ProduktuAldaketaPant frame, JMenuItem bDatuakAldatu) {
        bDatuakAldatu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                BezeroAldaketaPant a = new BezeroAldaketaPant();
                a.setLocationRelativeTo(null);
                a.setVisible(true);
            }
        });

    }

    /**
     * Saioa itxi nahi duen botoia sakatu eta Login klasean sartzen duen metodoa.
     */
    public static void bSaioaItxiJOption(ProduktuAldaketaPant frame, JMenuItem bSaioaItxi) {
        bSaioaItxi.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                int opcion = JOptionPane.showConfirmDialog(null, "Saioa itxi nahi duzu?", "", JOptionPane.YES_NO_OPTION);
                if (opcion == JOptionPane.YES_OPTION) {
                    Login login = new Login();
                    login.setLocationRelativeTo(null);
                    login.setVisible(true);
                } else {
                    frame.setVisible(true);
                }
            }
        });
    }

}