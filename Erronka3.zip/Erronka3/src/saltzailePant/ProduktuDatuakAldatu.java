package saltzailePant;

import java.awt.GridLayout;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import datuBase.DB;

/**
 * {@code ProduktuDatuakAldatu} klaseak produktuen datuak aldatzeko aukera ematen duen
 * grafikoa da.
 */
public class ProduktuDatuakAldatu extends JFrame{

    private static final long serialVersionUID = 1L;
    DB datuBase;
    static int idSele;
    static int minSal;
    static int maxSal;
    static String kategori;
    JPanel dPanel;
    JPanel dPaneles;
    JLabel lIzena;
    JLabel lDeskribapena;
    JLabel lBalio;
    JLabel lSalneurria;
    JLabel lKategoria;

    JTextField tIzena;
    JTextField tDeskribapena;
    JTextField tBalio;
    JTextField tSalneurria;
    JTextField tKategoria;

    /**
     * ProduktuDatuakAldatu klasearen eraikitzailea.
     * 
     * @param id		Produktuaren identifikatzailea.
     * @param min		Salneurriaren minimo balioa.
     * @param max       Salneurriaren maximo balioa.
     * @param kategoria Produktuak kategoriaren arabera filtratzeko erabiliko den kategoria.
     */
    public ProduktuDatuakAldatu (int id, int min, int max, String kategoria){
        idSele=id;
        minSal = min;
        maxSal = max;
        kategori = kategoria;
        datuBase = new DB();

        // Panelera gehitu botoiak
        JPanel dPanel = new JPanel(new GridLayout(5, 2));
        JPanel dPaneles = new JPanel();

        // JLabel textua jarri.
        lIzena = new JLabel("IZENA:");
        lDeskribapena = new JLabel("DESKRIBAPENA:");
        lBalio = new JLabel("BALIOA:");
        lSalneurria = new JLabel("SALNEURRIA:");
        lKategoria = new JLabel("KATEGORIA:");

        //TextField sortu
        tIzena = new JTextField (datuBase.getInfoProduktuTable("IZENA", idSele),20);
        tDeskribapena = new JTextField (datuBase.getInfoProduktuTable("DESKRIBAPENA", idSele),20);
        tBalio = new JTextField (datuBase.getInfoProduktuTable("BALIOA", idSele),20);
        tSalneurria = new JTextField (datuBase.getInfoProduktuTable("SALNEURRIA", idSele),20);
        tKategoria = new JTextField (datuBase.getInfoProduktuTable("ID_KATEGORIA", idSele),20);

        // Sortu botoiak
        JButton bAldatu = new JButton("ALDATU");
        JButton bAtzera = new JButton("ATZERA");

        // Panelera elementuak gehitu
        dPanel.add(lIzena);
        dPanel.add(tIzena);
        dPanel.add(lDeskribapena);
        dPanel.add(tDeskribapena);
        dPanel.add(lBalio);
        dPanel.add(tBalio);
        dPanel.add(lSalneurria);
        dPanel.add(tSalneurria);
        dPanel.add(lKategoria);
        dPanel.add(tKategoria);
        dPaneles.add(dPanel);
        dPaneles.add(bAldatu);
        dPaneles.add(bAtzera);

        // Panela dialog gehitus
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().add(dPaneles);  
        this.setSize(550, 200);

        bAldatu.addActionListener(e -> datuakAldatu());
        bAtzera.addActionListener(e -> atzera());
    }

    /**
     * Datu basean egindako aldaketa guztiak gorde eta grafiko berri bat ireki.
     */
    public void datuakAldatu() {
        String izena = tIzena.getText();
        String deskribapena = tDeskribapena.getText();
        double balioa = Double.parseDouble(tBalio.getText());
        double salneurria = Double.parseDouble(tSalneurria.getText());
        int kategoria = Integer.parseInt(tKategoria.getText());
        this.dispose();
        int opcion = JOptionPane.showConfirmDialog(null, "Datuak aldatu nahi dituzu?", "", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            try {
                datuBase.eguneratuProduktuTable(idSele, izena, deskribapena, balioa, salneurria, kategoria);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ProduktuAldaketaPant a = new ProduktuAldaketaPant(idSele, minSal, maxSal, kategori);
            a.setLocationRelativeTo(null);
            a.setVisible(true);
        } else {
            this.setVisible(true);
        }
    }

    /**
     * ProduktuDatuakAldatu klasea ixten duen eta ProduktuAldaketaPant klasean itzultzen duen metodoa.
     */
    public void atzera() {
        this.dispose();
        ProduktuAldaketaPant a = new ProduktuAldaketaPant(idSele, minSal, maxSal, kategori);
        a.setLocationRelativeTo(null);
        a.setVisible(true);
    }
}
